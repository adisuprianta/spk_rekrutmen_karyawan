<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateTableCalonKaryawan extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('table__calon_karyawan', function (Blueprint $table) {
            $table->char('id_calon_karyawan',5)->unsigned();
            $table->string('Nama_Calon_karyawan',30);
            $table->string('Email',20);
            $table->string('No_Hp',13);
            $table->string('Alamat',50);
            $table->string('NIK',16);
            $table->date('Tanggal_daftar');
            $table->string('Pendidikan',20);
            $table->date('Tanggal_Lahir');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('table__calon_karyawan');
    }
}
