<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateTableBerkasCalonKaryawan extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('berkas_calon_karyawan', function (Blueprint $table) {
            $table->increments('id_berkas')->unsigned();
            $table->String('Nama_Berkas',25);
            $table->String('Type_Berkas',30);
            $table->integer('size');
            $table->binary('Content');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('table_berkas_calon_karyawan');
    }
}
