<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateTableKriteriaAhp extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('table_kriteria_ahp', function (Blueprint $table) {
            $table->char('id_kriteria',5)->unsigned();
            $table->string('Nama_kriteria',20);
            $table->decimal('bobot_kriteria',3,4);
            $table->integer('Nilai_perbandingan_kriteria');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('table_kriteria_ahp');
    }
}
