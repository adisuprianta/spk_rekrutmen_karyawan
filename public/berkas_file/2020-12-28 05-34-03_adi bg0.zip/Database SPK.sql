/*==============================================================*/
/* DBMS name:      ORACLE Version 11g                           */
/* Created on:     16/12/2020 07:07:08                          */
/*==============================================================*/


alter table BERKAS_CALON_KARYAWAN
   drop constraint FK_BERKAS_C_RELATIONS_CALON_KA;

alter table BOBOT_CALON_KARYAWAN
   drop constraint FK_BOBOT_CA_RELATIONS_NILAI_KR;

alter table BOBOT_SUB_KARYAWAN
   drop constraint FK_BOBOT_SU_RELATIONS_NILAI_SU;

alter table CALON_KARYAWAN
   drop constraint FK_CALON_KA_RELATIONS_HRD_LOGI;

alter table CALON_KARYAWAN
   drop constraint FK_CALON_KA_RELATIONS_BAGIAN;

alter table KRITERIA_AHP
   drop constraint FK_KRITERIA_RELATIONS_BAGIAN;

alter table NILAI_KRITERIA
   drop constraint FK_NILAI_KR_RELATIONS_CALON_KA;

alter table NILAI_KRITERIA
   drop constraint FK_NILAI_KR_RELATIONS_KRITERIA;

alter table NILAI_SUB_SAW
   drop constraint FK_NILAI_SU_RELATIONS_CALON_KA;

alter table NILAI_SUB_SAW
   drop constraint FK_NILAI_SU_RELATIONS_SUB_KRIT;

alter table SUB_KRITERIA_AHP
   drop constraint FK_SUB_KRIT_RELATIONS_KRITERIA;

drop table BAGIAN cascade constraints;

drop index RELATIONSHIP_4_FK;

drop table BERKAS_CALON_KARYAWAN cascade constraints;

drop index RELATIONSHIP_13_FK;

drop table BOBOT_CALON_KARYAWAN cascade constraints;

drop index RELATIONSHIP_10_FK;

drop table BOBOT_SUB_KARYAWAN cascade constraints;

drop index RELATIONSHIP_11_FK;

drop index RELATIONSHIP_3_FK;

drop table CALON_KARYAWAN cascade constraints;

drop table HRD_LOGIN cascade constraints;

drop index RELATIONSHIP_1_FK;

drop table KRITERIA_AHP cascade constraints;

drop index RELATIONSHIP_12_FK;

drop index RELATIONSHIP_7_FK;

drop table NILAI_KRITERIA cascade constraints;

drop index RELATIONSHIP_14_FK;

drop index RELATIONSHIP_9_FK;

drop table NILAI_SUB_SAW cascade constraints;

drop index RELATIONSHIP_2_FK;

drop table SUB_KRITERIA_AHP cascade constraints;

/*==============================================================*/
/* Table: BAGIAN                                                */
/*==============================================================*/
create table BAGIAN 
(
   ID_BAGIAN            CHAR(3)              not null,
   NAMA_BAGIAN          VARCHAR2(20),
   constraint PK_BAGIAN primary key (ID_BAGIAN)
);

/*==============================================================*/
/* Table: BERKAS_CALON_KARYAWAN                                 */
/*==============================================================*/
create table BERKAS_CALON_KARYAWAN 
(
   ID_BERKAS            INTEGER              not null,
   ID_CALON_KARYAWAN    INTEGER,
   NAMA_BERKAS          VARCHAR2(255),
   constraint PK_BERKAS_CALON_KARYAWAN primary key (ID_BERKAS)
);

/*==============================================================*/
/* Index: RELATIONSHIP_4_FK                                     */
/*==============================================================*/
create index RELATIONSHIP_4_FK on BERKAS_CALON_KARYAWAN (
   ID_CALON_KARYAWAN ASC
);

/*==============================================================*/
/* Table: BOBOT_CALON_KARYAWAN                                  */
/*==============================================================*/
create table BOBOT_CALON_KARYAWAN 
(
   ID_BOBOT_CAKAR       CHAR(5)              not null,
   ID_NILAI             CHAR(5),
   NILAI_BOBOT_CAKAR    NUMBER(18,4),
   constraint PK_BOBOT_CALON_KARYAWAN primary key (ID_BOBOT_CAKAR)
);

/*==============================================================*/
/* Index: RELATIONSHIP_13_FK                                    */
/*==============================================================*/
create index RELATIONSHIP_13_FK on BOBOT_CALON_KARYAWAN (
   ID_NILAI ASC
);

/*==============================================================*/
/* Table: BOBOT_SUB_KARYAWAN                                    */
/*==============================================================*/
create table BOBOT_SUB_KARYAWAN 
(
   ID_BOBOT_SUB         CHAR(5)              not null,
   ID_NILAI_SUB         CHAR(5),
   NILAI_BOBOT_SUB      NUMBER(18,4),
   constraint PK_BOBOT_SUB_KARYAWAN primary key (ID_BOBOT_SUB)
);

/*==============================================================*/
/* Index: RELATIONSHIP_10_FK                                    */
/*==============================================================*/
create index RELATIONSHIP_10_FK on BOBOT_SUB_KARYAWAN (
   ID_NILAI_SUB ASC
);

/*==============================================================*/
/* Table: CALON_KARYAWAN                                        */
/*==============================================================*/
create table CALON_KARYAWAN 
(
   ID_CALON_KARYAWAN    INTEGER              not null,
   ID_HRD               INTEGER,
   ID_BAGIAN            CHAR(3),
   NAMA_CALON_KARYAWAN  VARCHAR2(30),
   EMAIL                VARCHAR2(20),
   NO_HP                VARCHAR2(13),
   ALAMAT               VARCHAR2(50),
   NIK                  VARCHAR2(16),
   TANGGAL_DAFTAR       DATE,
   PENDIDIKAN           VARCHAR2(20),
   TANGGAL_LAHIR        DATE,
   constraint PK_CALON_KARYAWAN primary key (ID_CALON_KARYAWAN)
);

/*==============================================================*/
/* Index: RELATIONSHIP_3_FK                                     */
/*==============================================================*/
create index RELATIONSHIP_3_FK on CALON_KARYAWAN (
   ID_BAGIAN ASC
);

/*==============================================================*/
/* Index: RELATIONSHIP_11_FK                                    */
/*==============================================================*/
create index RELATIONSHIP_11_FK on CALON_KARYAWAN (
   ID_HRD ASC
);

/*==============================================================*/
/* Table: HRD_LOGIN                                             */
/*==============================================================*/
create table HRD_LOGIN 
(
   ID_HRD               INTEGER              not null,
   NAMA_HRD             VARCHAR2(255),
   EMAIL_HRD            VARCHAR2(255),
   PASSWORD             VARCHAR2(255),
   constraint PK_HRD_LOGIN primary key (ID_HRD)
);

/*==============================================================*/
/* Table: KRITERIA_AHP                                          */
/*==============================================================*/
create table KRITERIA_AHP 
(
   ID_KRITERIA          CHAR(5)              not null,
   ID_BAGIAN            CHAR(3),
   NAMA_KRITERIA        VARCHAR2(20),
   BOBOT_KRITERIA       NUMBER(18,4),
   NILAI_PERBANDINGAN_KRITERIA INTEGER,
   constraint PK_KRITERIA_AHP primary key (ID_KRITERIA)
);

/*==============================================================*/
/* Index: RELATIONSHIP_1_FK                                     */
/*==============================================================*/
create index RELATIONSHIP_1_FK on KRITERIA_AHP (
   ID_BAGIAN ASC
);

/*==============================================================*/
/* Table: NILAI_KRITERIA                                        */
/*==============================================================*/
create table NILAI_KRITERIA 
(
   ID_NILAI             CHAR(5)              not null,
   ID_CALON_KARYAWAN    INTEGER,
   ID_KRITERIA          CHAR(5),
   NILAI_KRITERIA       INTEGER,
   constraint PK_NILAI_KRITERIA primary key (ID_NILAI)
);

/*==============================================================*/
/* Index: RELATIONSHIP_7_FK                                     */
/*==============================================================*/
create index RELATIONSHIP_7_FK on NILAI_KRITERIA (
   ID_KRITERIA ASC
);

/*==============================================================*/
/* Index: RELATIONSHIP_12_FK                                    */
/*==============================================================*/
create index RELATIONSHIP_12_FK on NILAI_KRITERIA (
   ID_CALON_KARYAWAN ASC
);

/*==============================================================*/
/* Table: NILAI_SUB_SAW                                         */
/*==============================================================*/
create table NILAI_SUB_SAW 
(
   ID_NILAI_SUB         CHAR(5)              not null,
   ID_CALON_KARYAWAN    INTEGER,
   ID_SUB_KRITERIA      CHAR(5),
   NILAI_SUB_KRITERIA   INTEGER,
   constraint PK_NILAI_SUB_SAW primary key (ID_NILAI_SUB)
);

/*==============================================================*/
/* Index: RELATIONSHIP_9_FK                                     */
/*==============================================================*/
create index RELATIONSHIP_9_FK on NILAI_SUB_SAW (
   ID_SUB_KRITERIA ASC
);

/*==============================================================*/
/* Index: RELATIONSHIP_14_FK                                    */
/*==============================================================*/
create index RELATIONSHIP_14_FK on NILAI_SUB_SAW (
   ID_CALON_KARYAWAN ASC
);

/*==============================================================*/
/* Table: SUB_KRITERIA_AHP                                      */
/*==============================================================*/
create table SUB_KRITERIA_AHP 
(
   ID_SUB_KRITERIA      CHAR(5)              not null,
   ID_KRITERIA          CHAR(5),
   NAMA_SUB_KRITERIA    VARCHAR2(20),
   BOBOT_SUB_KRITERIA   NUMBER(18,4),
   NILAI_PERBANDINGAN_SUB INTEGER,
   constraint PK_SUB_KRITERIA_AHP primary key (ID_SUB_KRITERIA)
);

/*==============================================================*/
/* Index: RELATIONSHIP_2_FK                                     */
/*==============================================================*/
create index RELATIONSHIP_2_FK on SUB_KRITERIA_AHP (
   ID_KRITERIA ASC
);

alter table BERKAS_CALON_KARYAWAN
   add constraint FK_BERKAS_C_RELATIONS_CALON_KA foreign key (ID_CALON_KARYAWAN)
      references CALON_KARYAWAN (ID_CALON_KARYAWAN);

alter table BOBOT_CALON_KARYAWAN
   add constraint FK_BOBOT_CA_RELATIONS_NILAI_KR foreign key (ID_NILAI)
      references NILAI_KRITERIA (ID_NILAI);

alter table BOBOT_SUB_KARYAWAN
   add constraint FK_BOBOT_SU_RELATIONS_NILAI_SU foreign key (ID_NILAI_SUB)
      references NILAI_SUB_SAW (ID_NILAI_SUB);

alter table CALON_KARYAWAN
   add constraint FK_CALON_KA_RELATIONS_HRD_LOGI foreign key (ID_HRD)
      references HRD_LOGIN (ID_HRD);

alter table CALON_KARYAWAN
   add constraint FK_CALON_KA_RELATIONS_BAGIAN foreign key (ID_BAGIAN)
      references BAGIAN (ID_BAGIAN);

alter table KRITERIA_AHP
   add constraint FK_KRITERIA_RELATIONS_BAGIAN foreign key (ID_BAGIAN)
      references BAGIAN (ID_BAGIAN);

alter table NILAI_KRITERIA
   add constraint FK_NILAI_KR_RELATIONS_CALON_KA foreign key (ID_CALON_KARYAWAN)
      references CALON_KARYAWAN (ID_CALON_KARYAWAN);

alter table NILAI_KRITERIA
   add constraint FK_NILAI_KR_RELATIONS_KRITERIA foreign key (ID_KRITERIA)
      references KRITERIA_AHP (ID_KRITERIA);

alter table NILAI_SUB_SAW
   add constraint FK_NILAI_SU_RELATIONS_CALON_KA foreign key (ID_CALON_KARYAWAN)
      references CALON_KARYAWAN (ID_CALON_KARYAWAN);

alter table NILAI_SUB_SAW
   add constraint FK_NILAI_SU_RELATIONS_SUB_KRIT foreign key (ID_SUB_KRITERIA)
      references SUB_KRITERIA_AHP (ID_SUB_KRITERIA);

alter table SUB_KRITERIA_AHP
   add constraint FK_SUB_KRIT_RELATIONS_KRITERIA foreign key (ID_KRITERIA)
      references KRITERIA_AHP (ID_KRITERIA);

